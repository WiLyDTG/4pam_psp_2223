package com.example.psp4pam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Psp4pamApplicationTests {

	@Test
	void contextLoads() {
	}

}
