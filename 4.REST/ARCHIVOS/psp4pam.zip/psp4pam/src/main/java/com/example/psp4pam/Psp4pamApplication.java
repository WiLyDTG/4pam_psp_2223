package com.example.psp4pam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Psp4pamApplication {

	public static void main(String[] args) {
		SpringApplication.run(Psp4pamApplication.class, args);
	}

}
