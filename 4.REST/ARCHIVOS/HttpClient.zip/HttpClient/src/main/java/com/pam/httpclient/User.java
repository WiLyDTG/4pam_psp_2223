/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pam.httpclient;

/**
 *
 * @author joaquinrios
 */
import com.fasterxml.jackson.annotation.JsonProperty;

public class User {
    public final Integer id;
    public final String name;
    public final String email;

    public User() {
        id = 0;
        name="";
        email="";
    }
    
    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }


    public User(String name,
                String email,
                Integer id) {
        this.name = name;
        this.email = email;
        this.id = id;
    }
}
