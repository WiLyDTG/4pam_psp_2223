/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pam.httpclient;

/**
 *
 * @author joaquinrios
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import org.apache.http.NameValuePair;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ApacheHttpClient {

    private static User usuario;
    private static ArrayList<User> listaUsuarios;
    private static HttpPost post = new HttpPost();
    private static HttpGet get = new HttpGet();
    private static final CloseableHttpClient httpClient = HttpClients.createDefault();
    private static final JSONParser jsonParser = new JSONParser();

    public static void main(String[] args) {

        listaUsuarios = getListaUsuarios();

        usuario = postInserta(new User("jorge", "pepito@gmail.com" , 0 ));
        System.out.println(usuario.getId());
        

        usuario = getUsuario(4);
        System.out.println("----------------------");
        System.out.println("ID : " + usuario.getId());
        System.out.println("Nombre : " + usuario.getName());
        System.out.println("Email : " + usuario.getEmail());
        

        System.out.println(getBorra(2));
        

        var sdsd = postActualiza(new User("juan", "juan@mail.com", 8));
        if (sdsd.getId() == 0) {
            System.out.println("ERROR AL ACTUALIZAR");
        } else {
            System.out.println("ACTUALIZADO CORRECTO");
        }
        
        /*
        for (User pepe : listaUsuarios) {
            System.out.println("----------------------");
            System.out.println("ID : " + pepe.getId());
            System.out.println("Nombre : " + pepe.getName());
            System.out.println("Email : " + pepe.getEmail());
        }
        */

        try {
            httpClient.close();
        } catch (IOException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public static User postInserta(User usuarioInsertar) {

        //Nuestra petición POST
        post = new HttpPost("http://localhost:8080/users/add");
        //Creamos la lista de valores a enviar
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("name", usuarioInsertar.getName()));
        urlParameters.add(new BasicNameValuePair("email", usuarioInsertar.getEmail()));
        //El objeto devuelto por el servidor REST
        User output = new User();
        
        try {
            //Codificamos los datos para enviarlos
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
            //Ejecutamos la consulta
            var response = httpClient.execute(post);
            //Leemos la respuesta en crudo
            BufferedReader br = new BufferedReader(
                    new InputStreamReader((response.getEntity().getContent())));
            //Comprobamos el tipo de respuesta
            int status = response.getStatusLine().getStatusCode();
            //La respuesta tiene status correcto
            if (status >= 200 && status < 300) {
                String jsonText = readAll(br);
                try {
                    var json = (JSONObject) jsonParser.parse(jsonText);
                    listaUsuarios.add(usuarioInsertar);
                } catch (ParseException ex) {
                    Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            // Recibimos un error HHTP
            } else {
                var nns = response.getStatusLine().toString();
                output = new User(nns, nns, 0);
            }
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return output;
    }

    public static User postActualiza(User usuarioActualizar) {
        
        User output = new User();
        post = new HttpPost("http://localhost:8080/users/user/" + usuarioActualizar.getId());
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("name", usuarioActualizar.getName()));
        urlParameters.add(new BasicNameValuePair("email", usuarioActualizar.getEmail()));

        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
            var response = httpClient.execute(post);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader((response.getEntity().getContent())));
            int status = response.getStatusLine().getStatusCode();
            if (status >= 200 && status < 300) {
                String jsonText = readAll(br);
                try {
                    var json = (JSONObject) jsonParser.parse(jsonText);
                    output = usuarioActualizar;
                    // Aqui falta por actualizar el ArrayList de usuarios con los valores 
                    // modificados del usuario
                } catch (ParseException ex) {
                    Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                var nns = response.getStatusLine().toString();
                output = new User(nns, "", 0);
            }

        } catch (IOException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return output;

    }

    public static String getBorra(int id) {
        var textResponse = "";
        String url = "http://localhost:8080/users/user/" + id;
        try {
            get = new HttpGet(url);
            var response = httpClient.execute(get);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader((response.getEntity().getContent())));
            int status = response.getStatusLine().getStatusCode();
            if (status >= 200 && status < 300) {
                textResponse = "BORRADO OK";
            } else {
                textResponse = "ERROR " + status;
                //textResponse = response.getStatusLine().toString();
            }
        } catch (IOException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return textResponse;
    }

    public static User getUsuario(int id) {

        var url = "http://localhost:8080/users/user?id=" + id;
        User elusuario = new User();
        String textResponse = "";

        try {

            get = new HttpGet(url);
            var response = httpClient.execute(get);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader((response.getEntity().getContent())));
            int status = response.getStatusLine().getStatusCode();
            if (status >= 200 && status < 300) {
                String jsonText = readAll(br);
                try {
                    var json = (JSONObject) jsonParser.parse(jsonText);
                    var idusu = Integer.parseInt(json.get("id").toString());
                    elusuario = new User(json.get("name").toString(),
                            json.get("email").toString(),
                            idusu);
                    usuario = elusuario;
                } catch (ParseException ex) {
                    Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                textResponse = "ERROR " + status;
                //textResponse = response.getStatusLine().toString();
            }

        } catch (IOException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return elusuario;
    }

    public static ArrayList<User> getListaUsuarios()  {
        ArrayList<User> listaUsuariosDevolver = new ArrayList<>();
            User elusuario = new User();
            var url = "http://localhost:8080/users/all/";
            String textResponse = "";
            
        try {
            get = new HttpGet(url);
            var response = httpClient.execute(get);
            BufferedReader br = new BufferedReader(
                    new InputStreamReader((response.getEntity().getContent())));
            int status = response.getStatusLine().getStatusCode();
            if (status >= 200 && status < 300) {
                try {
                    var jsonText = readAll(br);
                    JSONArray listaUsuariosJSON = (JSONArray) jsonParser.parse(jsonText);
                    Iterator i = listaUsuariosJSON.iterator();
                     //Vamo recorriendo el JSONArray
                    while (i.hasNext()) {
                       //jason guarda un usuario
                        var json = (JSONObject) i.next();
                        //obtenemos el id parseando el campo correspondiente
                        var idusu = Integer.parseInt(json.get("id").toString());
                        usuario = new User(json.get("name").toString(),
                                json.get("email").toString(),
                                idusu);
                        listaUsuariosDevolver.add(usuario);
                    }
                } catch (IOException | ParseException ex) {
                    Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } else {
                textResponse = response.getStatusLine().toString();
            }
        } catch (IOException ex) {
            Logger.getLogger(ApacheHttpClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaUsuariosDevolver;
    }

    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

}
